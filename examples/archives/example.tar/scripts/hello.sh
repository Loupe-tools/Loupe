#!/bin/sh
echo 'Loupe tar sample'
