Loupe tar archive sample. Contains plain-text and a nested script for renderer testing.
